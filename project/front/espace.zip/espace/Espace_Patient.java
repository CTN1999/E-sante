package project.front.espace;
import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

import project.back.untils.Utilitaire;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JTextPane;
import java.awt.Font;
import javax.swing.JScrollBar;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.BevelBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

public class Espace_Patient extends JFrame{
	private JPanel paneltitre;
	private JLabel lblNewLabel;
	private JPanel panelsoumission;
	private JButton btnMessage;
	private JPanel panelreponse;
	private JButton backBtn;
	private ButtonGroup buttonGroup7 ;
	private ButtonGroup buttonGroup1 ;
	private ButtonGroup buttonGroup2 ;
	private ButtonGroup buttonGroup3 ;
	private ButtonGroup buttonGroup4 ;
	private ButtonGroup buttonGroup5 ;
	private ButtonGroup buttonGroup6 ;
	private ButtonGroup buttonGroup8 ;
	private String reponse;
	private JPanel panel;
	private JTextField textField;

	public Espace_Patient() {
		getContentPane().setBackground(Color.WHITE);
		createInstanceComponents();
		initComponents ();
	}
	
		
	private void createInstanceComponents() {
		paneltitre = new JPanel();
		lblNewLabel = new JLabel("NOM_PATIENT");
		btnMessage = new JButton("MESSAGE");
		panelsoumission = new JPanel();
		panelreponse = new JPanel();
		panelreponse.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		panelreponse.add(scrollPane, BorderLayout.CENTER);
		
		JTextPane textPane = new JTextPane();
		scrollPane.setViewportView(textPane);
		backBtn = new JButton("Deconnexion");
		backBtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		backBtn.setForeground(Color.BLACK);
		backBtn.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		backBtn.setBackground(new Color(32, 178, 170));
		buttonGroup7 = new ButtonGroup();
		buttonGroup8 = new ButtonGroup();
		buttonGroup1 = new ButtonGroup();
		buttonGroup2 = new ButtonGroup();
		buttonGroup3 = new ButtonGroup();
		buttonGroup4 = new ButtonGroup();
		buttonGroup5 = new ButtonGroup();
		buttonGroup6 = new ButtonGroup();
		
		
	}
	private void initComponents () {
		setResizable(false);
		setTitle("E-sante");
		setSize(new Dimension(700, 500));
		getContentPane().setLayout(null);

		
		paneltitre.setBackground(new Color(32, 178, 170));
		paneltitre.setBounds(10, 11, 664, 56);
		getContentPane().add(paneltitre);
		paneltitre.setLayout(null);

		
		lblNewLabel.setFont(new Font("Trebuchet MS", Font.ITALIC, 30));
		lblNewLabel.setForeground(new Color(255, 255, 255));
		lblNewLabel.setBounds(231, 11, 198, 34);
		paneltitre.add(lblNewLabel);

		
		panelsoumission.setBackground(new Color(32, 178, 170));
		panelsoumission.setBounds(427, 87, 247, 63);
		getContentPane().add(panelsoumission);
		panelsoumission.setLayout(null);

		
		btnMessage.setFont(new Font("Tw Cen MT", Font.BOLD | Font.ITALIC, 20));
		btnMessage.setBounds(34, 11, 159, 31);
		
		panelsoumission.add(btnMessage);

		
		panelreponse.setBackground(new Color(255, 255, 255));
		panelreponse.setBounds(427, 150, 247, 266);
		getContentPane().add(panelreponse);

		
		backBtn.setBounds(482, 427, 192, 29);
		getContentPane().add(backBtn);
		
		panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(10, 87, 405, 329);
		getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Demande Consultation:");
		lblNewLabel_1.setFont(new Font("Lucida Grande", Font.BOLD, 19));
		lblNewLabel_1.setBounds(50, 24, 283, 16);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Date:");
		lblNewLabel_2.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		lblNewLabel_2.setBounds(16, 52, 61, 16);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Structure De Sante:");
		lblNewLabel_3.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		lblNewLabel_3.setBounds(16, 93, 138, 16);
		panel.add(lblNewLabel_3);
		
		textField = new JTextField();
		textField.setBounds(156, 48, 130, 26);
		panel.add(textField);
		textField.setColumns(10);
		
		JComboBox comboBox = new JComboBox();
		comboBox.setBounds(166, 90, 130, 27);
		panel.add(comboBox);
		
		JButton btnNewButton = new JButton("Text Covid-19");
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(new Color(32, 178, 170));
		btnNewButton.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(26, 194, 148, 65);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("S'Inscrire Pour Le Vaccin");
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setBackground(new Color(32, 178, 170));
		btnNewButton_1.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		btnNewButton_1.setBounds(202, 194, 164, 65);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Demander");
		btnNewButton_2.setBackground(new Color(32, 178, 170));
		btnNewButton_2.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		btnNewButton_2.setBounds(113, 129, 117, 29);
		panel.add(btnNewButton_2);
		
		Utilitaire.center(this, this.getSize());
		
	}
	public void run() {
		this.setVisible(true);
	}
}


